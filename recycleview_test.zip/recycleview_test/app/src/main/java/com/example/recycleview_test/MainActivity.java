package com.example.recycleview_test;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.rec);
        ArrayList<Item> items = new ArrayList<Item>();
        items.add(new Item("Pic 1","pic1@gmail.com",R.drawable.u));
        items.add(new Item("Pic 2","pic2@gmail.com",R.drawable.y));
        items.add(new Item("Pic 3","pic3@gmail.com",R.drawable.z));

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(new ProgramAdt(getApplicationContext(),items));

    }
}